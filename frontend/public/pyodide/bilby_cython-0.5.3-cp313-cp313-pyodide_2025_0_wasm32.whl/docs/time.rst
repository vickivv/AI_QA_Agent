Time
----

Optimised time functions, mostly conversions to sidereal time from GPS time.

.. automodule:: bilby_cython.time
   :members:
